import isaacgym
import numpy as np
import legged_gym
import torch
from isaacgym import gymutil
from envs.base.legged_robot_config import LeggedRobotCfgPPO
from rsl_rl.runners import OnPolicyRunner1
from utils.helpers import get_args, update_cfg_from_args, class_to_dict, get_load_path, set_seed, parse_sim_params

envs = legged_gym.make(
    seed=0,
    task="Cartpole",
    num_envs=2000,
    sim_device="cuda:0",
    rl_device="cuda:0",
    # graphics_device_id=0,    # visualize
    # force_render="True",
)


train_cfg = LeggedRobotCfgPPO
args = get_args()
_, train_cfg = update_cfg_from_args(None, train_cfg, args)
train_cfg_dict = class_to_dict(train_cfg)
runner = OnPolicyRunner1(envs, train_cfg_dict, device=args.rl_device, log_dir='./')
runner.learn(num_learning_iterations=train_cfg.runner.max_iterations, init_at_random_ep_len=False)